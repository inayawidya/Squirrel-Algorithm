/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ssa;

/**
 *
 * @author User
 */
public interface Param {
    
    static final Integer N = 5;
    static final Integer D = 30;
    static final Double PDP = 0.1;
    static final Double DG = 0.6;
    static final Double GC = 1.9;
    static final Integer MAX_ITER = 1;
    static final Double LAMBDA = 1.5;
}
